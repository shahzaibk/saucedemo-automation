import java.math.BigDecimal;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SauceDemoCheckoutTest {
    private WebDriver driver;
    private WebDriverWait wait;

    private static final String BASE_URL = "https://www.saucedemo.com/";
    private static final String USERNAME = System.getenv().getOrDefault(
            "SAUCEDEMO_USERNAME", "standard_user");
    private static final String PASSWORD = System.getenv().getOrDefault(
            "SAUCEDEMO_PASSWORD", "secret_sauce");

    @BeforeMethod
    public void setUp() {
        var options = new org.openqa.selenium.chrome.ChromeOptions();
        if ("1".equals(System.getenv("HEADLESS"))) {
            options.addArguments("--headless=new");
            options.addArguments("--window-size=1440,1000");
        }
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(BASE_URL);
    }

    @Test
    public void verifySuccessfulCheckout() {
        // Login
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.id("user-name"))).sendKeys(USERNAME);
        driver.findElement(By.id("password")).sendKeys(PASSWORD);
        driver.findElement(By.id("login-button")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.className("inventory_list")));
        Assert.assertEquals(driver.findElement(By.className("title")).getText(),
                "Products", "Products page should be shown after login");

        // Add a known product to the cart
        By addBackpack = By.id("add-to-cart-sauce-labs-backpack");
        wait.until(ExpectedConditions.elementToBeClickable(addBackpack)).click();
        Assert.assertEquals(
                wait.until(ExpectedConditions.visibilityOfElementLocated(
                        By.className("shopping_cart_badge"))).getText(),
                "1", "Cart badge should show one item");

        // Verify cart contents
        driver.findElement(By.className("shopping_cart_link")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cart_item")));
        Assert.assertEquals(driver.findElement(
                By.className("inventory_item_name")).getText(),
                "Sauce Labs Backpack", "Expected product should be in cart");
        Assert.assertEquals(driver.findElement(By.className("cart_quantity")).getText(),
                "1", "Cart quantity should be one");

        // Checkout details
        driver.findElement(By.id("checkout")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("first-name")));
        driver.findElement(By.id("first-name")).sendKeys("QA");
        driver.findElement(By.id("last-name")).sendKeys("Tester");
        driver.findElement(By.id("postal-code")).sendKeys("44000");
        driver.findElement(By.id("continue")).click();

        // Verify summary and monetary calculation
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.className("summary_info")));
        Assert.assertEquals(driver.findElement(
                By.className("inventory_item_name")).getText(),
                "Sauce Labs Backpack", "Checkout summary should show selected product");

        BigDecimal subtotal = readPrice(By.className("summary_subtotal_label"));
        BigDecimal tax = readPrice(By.className("summary_tax_label"));
        BigDecimal total = readPrice(By.className("summary_total_label"));
        BigDecimal itemPrice = readPrice(By.className("inventory_item_price"));

        Assert.assertEquals(subtotal.compareTo(itemPrice), 0,
                "Subtotal should match the selected product price");
        Assert.assertEquals(subtotal.add(tax).compareTo(total), 0,
                "Total should equal subtotal plus tax");

        // Finish and verify confirmation
        driver.findElement(By.id("finish")).click();
        WebElement confirmation = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.className("complete-header")));
        Assert.assertEquals(confirmation.getText(),
                "Thank you for your order!", "Order confirmation should be shown");
        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-complete.html"),
                "Should navigate to the order completion page");
    }

    private BigDecimal readPrice(By locator) {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(locator))
                .getText();
        String amount = text.replaceAll("[^0-9.]", "");
        return new BigDecimal(amount);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
