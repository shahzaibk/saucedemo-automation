# SauceDemo Selenium Java E2E Test

## End-to-end flow
Login → add Sauce Labs Backpack → verify cart → checkout → verify subtotal/tax/total → finish order → verify confirmation.

## Prerequisites
- JDK 17+
- Maven 3.8+
- Google Chrome
- Internet access to https://www.saucedemo.com/

Selenium Manager (included in Selenium 4) normally resolves a compatible ChromeDriver automatically. Some environments may need driver/network configuration.

## Run
From this project directory:

```bash
mvn clean test
```

To run headlessly:
- Windows PowerShell: `$env:HEADLESS="1"; mvn clean test`
- macOS/Linux: `HEADLESS=1 mvn clean test`

Optional credentials can be set with `SAUCEDEMO_USERNAME` and `SAUCEDEMO_PASSWORD`. The defaults are public SauceDemo demo credentials, not real account credentials.

## AI use and review notes
AI assisted with the initial test design, Selenium locator selection, explicit waits, assertions, Maven configuration, and documentation. Review and execute the generated code before submission; do not claim a pass without a successful run.

Manual quality choices in this version:
- Uses stable IDs for most controls.
- Uses explicit waits instead of fixed sleeps.
- Creates and closes a fresh browser for each test.
- Verifies login, cart item/quantity, checkout product, displayed monetary calculation, and confirmation.

## Limitations / risks
- This is a single happy-path UI test on a public demo store.
- It does not test invalid login, missing checkout fields, inventory errors, backend persistence, or real payment processing.
- Website changes, network issues, browser compatibility, or demo-account changes may cause failures.
- UI-displayed subtotal/tax/total are checked for arithmetic consistency, not against an independent backend source.
- Test code has not been executed as part of creating this archive; record the actual test result after running it.
